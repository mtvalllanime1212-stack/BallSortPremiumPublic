# Ball Sort Premium (Android)

Native Android Jetpack Compose starter game with a premium glass-style interface.

## Game features
- Ball sorting gameplay with tube selection
- Move counter, undo and restart
- Progression through 500,000 procedural level seeds
- Offline gameplay

## Music features
- MY SONGS opens Android's document picker and plays audio files selected from the phone.
- Play/Pause and Stop controls.
- SONG CATALOG screen explains the licensed streaming integration requirement.
- Popular commercial Hindi songs are not bundled: streaming them requires a licensed music provider, API integration and any required user subscription. Add the provider's approved SDK/API before publishing a streaming catalogue.

## Build
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Select Run to install on an emulator or connected Android phone.
5. To create an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Release checklist
Test puzzle solvability and difficulty across many levels, test audio playback on target devices, add app icon/accessibility/localization, complete privacy disclosures if adding analytics/ads, and sign a release build.


## Build APK using only an Android phone (GitHub cloud build)
1. Download and extract this ZIP using your phone's Files app.
2. In your mobile browser, sign in to GitHub and create a new repository.
3. Upload the extracted project files/folders to the repository (including the hidden `.github/workflows/build-apk.yml` file).
4. Open the repository's Actions tab and run **Build Android APK** (or push to `main`).
5. When the workflow finishes, open its run, scroll to Artifacts, and download `BallSortPremium-debug-apk`.
6. Extract the downloaded artifact ZIP, tap `app-debug.apk`, and allow installation from that source if Android asks.

A GitHub account and internet access are required for this cloud build. The resulting debug APK is for testing; a signed release APK is needed for distribution.
