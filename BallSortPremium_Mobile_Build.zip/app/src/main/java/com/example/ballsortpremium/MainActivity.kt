package com.example.ballsortpremium

import android.os.Bundle
import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BallSortApp() }
    }
}

private val palette = listOf(
    Color(0xFFFF5C8A), Color(0xFF42D6C5), Color(0xFFFFC857),
    Color(0xFF8B7CFF), Color(0xFF59A8FF), Color(0xFFFF8A4C),
    Color(0xFFB7E36A), Color(0xFFE879F9), Color(0xFF67E8F9),
    Color(0xFFF472B6), Color(0xFFA3E635), Color(0xFFFDA4AF)
)

private data class GameSnapshot(val tubes: List<List<Int>>, val selected: Int?)

private fun makeLevel(level: Int): List<List<Int>> {
    val colors = (2 + (level / 8).coerceAtMost(8)).coerceAtMost(10)
    val capacity = 4
    val tubes = MutableList(colors + 2) { mutableListOf<Int>() }
    for (c in 0 until colors) repeat(capacity) { tubes[c].add(c) }

    // Reverse a sequence of legal moves from a solved board.
    // This creates mixed tubes while preserving a guaranteed solution.
    val rng = Random(level * 7919 + 104729)
    val steps = (10 + level * 2).coerceAtMost(180)
    repeat(steps) {
        val donors = tubes.indices.filter { i ->
            tubes[i].isNotEmpty() && tubes[i].distinct().size == 1
        }
        if (donors.isNotEmpty()) {
            val from = donors.random(rng)
            val choices = tubes.indices.filter { it != from && tubes[it].size < capacity }
            if (choices.isNotEmpty()) {
                val to = choices.random(rng)
                val ball = tubes[from].removeAt(tubes[from].lastIndex)
                tubes[to].add(ball)
            }
        }
    }
    return tubes.map { it.toList() }
}

@Composable
private fun BallSortApp() {
    var level by remember { mutableIntStateOf(1) }
    var tubes by remember { mutableStateOf(makeLevel(1)) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var moves by remember { mutableIntStateOf(0) }
    var history by remember { mutableStateOf(listOf<GameSnapshot>()) }
    var won by remember { mutableStateOf(false) }
    val capacity = 4

    fun reset() {
        tubes = makeLevel(level); selected = null; moves = 0
        history = emptyList(); won = false
    }
    fun save() { history = history + GameSnapshot(tubes.map { it.toList() }, selected) }
    fun solved(board: List<List<Int>>) = board.all { it.isEmpty() || (it.size == capacity && it.distinct().size == 1) }

    fun tap(index: Int) {
        if (won) return
        val from = selected
        if (from == null) {
            if (tubes[index].isNotEmpty()) selected = index
            return
        }
        if (from == index) { selected = null; return }
        val source = tubes[from]
        val target = tubes[index]
        if (source.isEmpty()) { selected = null; return }
        val ball = source.last()
        if (target.size < capacity && (target.isEmpty() || target.last() == ball)) {
            save()
            val next = tubes.map { it.toMutableList() }
            next[from].removeAt(next[from].lastIndex)
            next[index].add(ball)
            tubes = next.map { it.toList() }
            moves++
            selected = null
            won = solved(tubes)
        } else {
            selected = if (target.isNotEmpty()) index else null
        }
    }

    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF10172F), Color(0xFF222C52), Color(0xFF10172F)))
        ).padding(20.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxSize()) {
            Spacer(Modifier.height(12.dp))
            Text("BALL SORT", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
            Text("PREMIUM • GLASS EDITION", color = Color(0xFFB8C7F5), fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(22.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                StatCard("LEVEL", "$level")
                StatCard("MOVES", "$moves")
                StatCard("TOTAL", "500K")
            }
            Spacer(Modifier.height(22.dp))
            Text("Tap a tube, then tap another tube", color = Color(0xFFDCE5FF), fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            MusicPanel()
            Spacer(Modifier.height(12.dp))

            val rows = (tubes.size + 3) / 4
            Column(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                tubes.chunked(4).forEachIndexed { rowIndex, row ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        row.forEachIndexed { colIndex, tube ->
                            val index = rowIndex * 4 + colIndex
                            Tube(
                                balls = tube,
                                capacity = capacity,
                                isSelected = selected == index,
                                onClick = { tap(index) },
                                modifier = Modifier.weight(1f).height(150.dp)
                            )
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }

            if (won) {
                Text("✨ LEVEL COMPLETE! ✨", color = Color(0xFFFFD76A), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionButton("UNDO", Modifier.weight(1f), enabled = history.isNotEmpty()) {
                    val previous = history.last()
                    tubes = previous.tubes
                    selected = previous.selected
                    history = history.dropLast(1)
                    moves = (moves - 1).coerceAtLeast(0)
                    won = false
                }
                ActionButton("RESTART", Modifier.weight(1f)) { reset() }
                ActionButton(if (won) "NEXT" else "LEVEL +", Modifier.weight(1f)) {
                    level = if (level >= 500000) 1 else level + 1
                    tubes = makeLevel(level); selected = null; moves = 0
                    history = emptyList(); won = false
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("500,000 levels • Offline play • No account needed", color = Color(0xFF8F9CC4), fontSize = 10.sp)
        }
    }
}



@Composable
private fun MusicPanel() {
    val context = LocalContext.current
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(false) }
    var selectedName by remember { mutableStateOf("No song selected") }
    var showCatalogInfo by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            try {
                player?.release()
                val newPlayer = MediaPlayer()
                newPlayer.setDataSource(context, uri)
                newPlayer.setOnCompletionListener { playing = false }
                newPlayer.prepare()
                newPlayer.start()
                player = newPlayer
                playing = true
                selectedName = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected Hindi song"
            } catch (_: Exception) {
                player?.release()
                player = null
                playing = false
                selectedName = "Could not play this audio file"
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            player?.release()
            player = null
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.075f))
            .border(1.dp, Color.White.copy(alpha = 0.20f), RoundedCornerShape(18.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("♫", color = Color(0xFFFFD76A), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("HINDI MUSIC", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(selectedName, color = Color(0xFFB8C7F5), fontSize = 10.sp, maxLines = 1)
            }
            TextButton(onClick = { picker.launch(arrayOf("audio/*")) }) {
                Text("MY SONGS", color = Color(0xFFFFD76A), fontSize = 10.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = {
                    if (player == null) {
                        picker.launch(arrayOf("audio/*"))
                    } else if (playing) {
                        player?.pause()
                        playing = false
                    } else {
                        player?.start()
                        playing = true
                    }
                },
                modifier = Modifier.weight(1f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
            ) {
                Text(if (playing) "PAUSE" else "PLAY", color = Color.White, fontSize = 10.sp)
            }
            OutlinedButton(
                onClick = {
                    player?.stop()
                    player?.release()
                    player = null
                    playing = false
                    selectedName = "No song selected"
                },
                modifier = Modifier.weight(1f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
            ) {
                Text("STOP", color = Color.White, fontSize = 10.sp)
            }
            OutlinedButton(
                onClick = { showCatalogInfo = true },
                modifier = Modifier.weight(1f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
            ) {
                Text("SONG CATALOG", color = Color.White, fontSize = 9.sp)
            }
        }
    }

    if (showCatalogInfo) {
        AlertDialog(
            onDismissRequest = { showCatalogInfo = false },
            containerColor = Color(0xFF202A4B),
            title = { Text("Hindi song catalogue", color = Color.White) },
            text = {
                Text(
                    "In-app streaming catalogue is planned. To provide popular Hindi songs, the app must connect to a music service that grants streaming rights (and may require an API key or subscription). No copyrighted songs are bundled in this starter project. You can already play audio files stored on your phone using MY SONGS.",
                    color = Color(0xFFDCE5FF)
                )
            },
            confirmButton = {
                TextButton(onClick = { showCatalogInfo = false }) {
                    Text("OK", color = Color(0xFFFFD76A))
                }
            }
        )
    }
}

@Composable
private fun StatCard(label: String, value: String) {
    Column(
        modifier = Modifier.clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(18.dp))
            .padding(horizontal = 18.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = Color(0xFF9EADD8), fontSize = 9.sp, letterSpacing = 1.sp)
        Text(value, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Tube(
    balls: List<Int>, capacity: Int, isSelected: Boolean,
    onClick: () -> Unit, modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(topStart = 13.dp, topEnd = 13.dp, bottomStart = 24.dp, bottomEnd = 24.dp))
            .background(Color.White.copy(alpha = 0.055f))
            .border(
                BorderStroke(if (isSelected) 2.dp else 1.dp,
                    if (isSelected) Color(0xFFFFD76A) else Color.White.copy(alpha = 0.42f)),
                RoundedCornerShape(topStart = 13.dp, topEnd = 13.dp, bottomStart = 24.dp, bottomEnd = 24.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.Bottom,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        repeat(capacity - balls.size) { Spacer(Modifier.weight(1f)) }
        balls.forEach { colorIndex ->
            Box(
                Modifier.fillMaxWidth(0.88f).weight(1f).padding(vertical = 2.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(
                        palette[colorIndex].copy(alpha = 0.72f),
                        palette[colorIndex],
                        palette[colorIndex].copy(alpha = 0.82f)
                    )))
                    .border(1.dp, Color.White.copy(alpha = 0.38f), RoundedCornerShape(50))
            )
        }
    }
}

@Composable
private fun ActionButton(
    label: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit
) {
    TextButton(
        onClick = onClick, enabled = enabled, modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = if (enabled) 0.12f else 0.04f))
            .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(14.dp))
    ) {
        Text(label, color = if (enabled) Color.White else Color(0xFF7883A5), fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
